import { OpenMakeup, MORPH_CONTROLS, MORPH_TARGETS_EXTRA } from './src/index.js';

const status = document.getElementById('status');
const $ = (id) => document.getElementById(id);

const MP = 'https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh@0.4.1633559619';

const mk = new OpenMakeup({
  video:        $('video'),
  renderCanvas: $('renderCanvas'),
  assetsBaseUrl: '/assets',
  mediapipeBaseUrl: MP,
  aiColor: async () => '#c21f4d',
});

try {
  status.textContent = 'Loading face model + shaders…';
  await mk.init();
  status.textContent = 'Ready. Allow the camera, then try makeup + reshape.';
  buildMorphSliders();
} catch (e) {
  status.textContent = 'Init failed: ' + (e?.message || e);
  console.error(e);
}

// ── makeup ──
$('lipstick').onclick   = () => mk.apply('lipstick',  { finish: 'glossy' });
$('eyeshadow').onclick  = () => mk.apply('eyeshadow', { color: '#7a3b9d', pattern: 1, finish: 'glitter' });
$('eyeline').onclick    = () => mk.apply('eyeline',   { pattern: 1 });
$('blush').onclick      = () => mk.apply('blush',     { color: '#e26d7a' });
$('foundation').onclick = () => mk.apply('foundation',{ color: '#d9b89c', finish: 'matte' });
$('mascara').onclick    = () => mk.apply('mascara',   {});
$('clear').onclick      = () => mk.clearAll();

// ── morph sliders (built from the SDK's own control list) ──
const sliders = [];

function makeSlider(name, about) {
  const row = document.createElement('label');
  row.className = 'slider';
  row.innerHTML =
    `<span>${name}${about ? ` — <i>${about}</i>` : ''}</span>` +
    `<input type="range" min="-1" max="1.5" step="0.05" value="0">` +
    `<output>0.00</output>`;
  const input = row.querySelector('input');
  const out = row.querySelector('output');
  input.addEventListener('input', () => {
    out.textContent = (+input.value).toFixed(2);
    mk.setMorph(name, +input.value);
  });
  $('morph-panel').appendChild(row);
  sliders.push({ input, out });
}

function buildMorphSliders() {
  for (const [name, cfg] of Object.entries(MORPH_CONTROLS)) makeSlider(name, cfg.about);
  const sep = document.createElement('div');
  sep.className = 'sep';
  sep.textContent = 'variants (raw targets)';
  $('morph-panel').appendChild(sep);
  for (const t of MORPH_TARGETS_EXTRA) makeSlider(t, '');
}

$('reset-morph').onclick = () => {
  mk.resetMorph();
  for (const s of sliders) { s.input.value = 0; s.out.textContent = '0.00'; }
};

window.mk = mk;
